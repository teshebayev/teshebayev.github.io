"""Общая часть: данные, сеть 64 → 32 → 10 и обучение мини-батчами на чистом NumPy."""
import numpy as np
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

def load_data(scale=16.0):
    d = load_digits()                               # 1797 картинок 8×8, значения 0…16
    X = d.data / scale
    Xtr, Xte, ytr, yte = train_test_split(X, d.target, test_size=450,
                                          stratify=d.target, random_state=0)
    return Xtr, Xte, ytr, yte

def init_params(seed=0, H=32):
    rng = np.random.default_rng(seed)
    W1 = rng.normal(0, np.sqrt(2/64), (64, H)); b1 = np.zeros(H)
    W2 = rng.normal(0, np.sqrt(2/H), (H, 10)); b2 = np.zeros(10)
    return [W1, b1, W2, b2]

def forward(params, X):
    W1, b1, W2, b2 = params
    Z1 = X @ W1 + b1
    A1 = np.maximum(Z1, 0)
    Z2 = A1 @ W2 + b2
    E = np.exp(Z2 - Z2.max(axis=1, keepdims=True))
    return Z1, A1, Z2, E / E.sum(axis=1, keepdims=True)

def loss(params, X, y):
    P = forward(params, X)[3]
    return -np.log(P[np.arange(len(y)), y]).mean()

def acc(params, X, y):
    return (forward(params, X)[3].argmax(1) == y).mean() * 100

def grads(params, Xb, Yb):
    W1, b1, W2, b2 = params
    Z1, A1, Z2, P = forward(params, Xb)
    dZ2 = (P - Yb) / len(Xb)
    dW2, db2 = A1.T @ dZ2, dZ2.sum(0)
    dZ1 = (dZ2 @ W2.T) * (Z1 > 0)
    dW1, db1 = Xb.T @ dZ1, dZ1.sum(0)
    return [dW1, db1, dW2, db2]

def batches(n, B, rng, shuffle=True, keep_tail=False):
    """Индексы батчей одной эпохи. По умолчанию хвост присоединяется к последнему батчу."""
    order = rng.permutation(n) if shuffle else np.arange(n)
    k = n // B
    if keep_tail:                                   # хвост — отдельным маленьким батчем
        return [order[i*B:(i+1)*B] for i in range(k)] + ([order[k*B:]] if n % B else [])
    return [order[i*B:(i+1)*B if i < k-1 else n] for i in range(k)]

def train(Xtr, ytr, Xte=None, yte=None, B=32, eta=0.3, epochs=30, shuffle=True,
          keep_tail=False, H=32, on_epoch=None, on_step=None):
    params = init_params(0, H)
    rng = np.random.default_rng(0)                  # отдельный генератор для перемешивания
    Ytr = np.eye(10)[ytr]
    for ep in range(1, epochs + 1):
        for idx in batches(len(Xtr), B, rng, shuffle, keep_tail):
            g = grads(params, Xtr[idx], Ytr[idx])
            if on_step: on_step(ep, idx, params, g)
            for p, dp in zip(params, g):
                p -= eta * dp
        if on_epoch: on_epoch(ep, params)
    return params
