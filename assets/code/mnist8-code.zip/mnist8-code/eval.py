"""Разбор результата: матрица ошибок и список всех ошибок (запускать после mnist8.py)."""
import numpy as np
from net import load_data, forward, acc

Xtr, Xte, ytr, yte = load_data()
f = np.load('params.npz'); params = [f[f'arr_{i}'] for i in range(4)]
P = forward(params, Xte)[3]; pred = P.argmax(1)
print(f'точность: {acc(params, Xte, yte):.2f}% ({(pred != yte).sum()} ошибок из {len(yte)})')
cm = np.zeros((10, 10), int)
np.add.at(cm, (yte, pred), 1)
print('матрица ошибок (строка — правда, столбец — ответ сети):'); print(cm)
print('\nвсе ошибки:')
for i in np.where(pred != yte)[0]:
    print(f'  цифра {yte[i]} → сеть говорит {pred[i]} с уверенностью {P[i, pred[i]]:.2f}'
          f'   (верному классу осталось {P[i, yte[i]]:.2f})')
