"""Сквозной пример: первые 4 картинки первого батча первой эпохи + сверка градиента."""
import numpy as np
from net import load_data, init_params, forward, loss, grads

Xtr, Xte, ytr, yte = load_data()
params = init_params(0)
idx = np.random.default_rng(0).permutation(len(Xtr))[:4]   # тот же генератор, что в обучении
Xb, yb = Xtr[idx], ytr[idx]; Yb = np.eye(10)[yb]
print('номера в обучающей выборке:', idx)
print('батч:', Xb.shape, ' метки:', yb)
L = loss(params, Xb, yb)
print(f'потеря на батче: {L:.4f}   (ln 10 = {np.log(10):.4f})')
Z1 = forward(params, Xb)[0]
print('открытых ReLU:', int((Z1 > 0).sum()), 'из', Z1.size)
g = grads(params, Xb, Yb)
print(f'норма градиента: {np.sqrt(sum((x**2).sum() for x in g)):.4f}')
print('нулевых строк в dW1:', int((np.abs(g[0]).sum(1) == 0).sum()), 'из 64')

eps, worst = 1e-5, 0.0
for p, dp in zip(params, g):
    for i in np.ndindex(p.shape):
        old = p[i]
        p[i] = old + eps; Lp = loss(params, Xb, yb)
        p[i] = old - eps; Lm = loss(params, Xb, yb)
        p[i] = old
        worst = max(worst, abs((Lp - Lm) / (2*eps) - dp[i]))
print(f'сверка центральными разностями по всем 2410 параметрам: {worst:.2e}')

# один шаг спуска на этом батче
for eta in (0.3, 3.0):
    q = [p - eta*dp for p, dp in zip(params, g)]
    print(f'после шага η = {eta}: потеря {L:.4f} → {loss(q, Xb, yb):.4f}')
