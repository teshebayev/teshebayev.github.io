"""Часть 2 (размер скрытого слоя) и часть 11: шесть экспериментов, меняется ровно один параметр."""
import numpy as np
from net import load_data, train, loss, acc, grads

Xtr, Xte, ytr, yte = load_data()
run = lambda **kw: acc(train(Xtr, ytr, **kw), Xte, yte)

print('скрытый слой:')
for H in (4, 8, 16, 32, 64, 128):
    print(f'  H = {H:3d}   параметров {64*H + H + H*10 + 10:5d}   точность {run(H=H):.2f}%')

print('\n1) длина шага η:')
for eta in (0.01, 0.1, 0.3, 1.0, 3.0):
    print(f'  η = {eta:<5}  {run(eta=eta):.2f}%')

print('\n2) размер батча (η = 0.3):')
for B in (1, 8, 32, 128, 1347):
    print(f'  B = {B:<5}  {run(B=B):.2f}%')

print('\n3) нормировка входа:')
Xr, Xre, _, _ = load_data(scale=1.0)
for eta in (0.3, 0.01):
    print(f'  0…16, η = {eta}:  {acc(train(Xr, ytr, eta=eta), Xre, yte):.2f}%')

print('\n4) перемешивание (обучающая выборка отсортирована по классам):')
o = np.argsort(ytr, kind='stable'); Xs, ys = Xtr[o], ytr[o]
print(f'  по порядку:  {acc(train(Xs, ys, shuffle=False), Xte, yte):.2f}%')
print(f'  вперемешку:  {acc(train(Xs, ys), Xte, yte):.2f}%')

print('\n5) хвост эпохи отдельным батчем из трёх картинок:')
worst = {}
def on_step(ep, idx, p, g):
    if len(idx) < 32:
        before = loss(p, Xtr, ytr); a0 = acc(p, Xtr, ytr)
        after_p = [x - 0.3*dx for x, dx in zip(p, g)]
        worst.setdefault('rows', []).append((loss(after_p, Xtr, ytr) - before, ep, before,
            loss(after_p, Xtr, ytr), a0, acc(after_p, Xtr, ytr), np.sqrt(sum((d**2).sum() for d in g))))
train(Xtr, ytr, keep_tail=True, on_step=on_step)
_, ep, l0, l1, a0, a1, gn = max(worst['rows'])
print(f'  худший шаг — эпоха {ep}: потеря {l0:.4f} → {l1:.4f}, '
      f'точность на обучающей {a0:.1f}% → {a1:.1f}%, норма градиента {gn:.2f}')

print('\n6) 200 эпох вместо 30:')
hist = []
train(Xtr, ytr, epochs=200, on_epoch=lambda ep, p: hist.append(
    (ep, loss(p, Xtr, ytr), loss(p, Xte, yte), acc(p, Xtr, ytr))))
best = min(hist, key=lambda h: h[2])
full = next(h[0] for h in hist if h[3] == 100)
print(f'  минимум отложенной потери {best[2]:.4f} на {best[0]}-й эпохе; '
      f'в конце {hist[-1][2]:.4f} при обучающей {hist[-1][1]:.4f}; 100% на обучающей с {full}-й эпохи')
