"""Основной прогон: данные, обучение 30 эпох, лог как в статье."""
import numpy as np
from net import load_data, train, loss, acc

Xtr, Xte, ytr, yte = load_data()
print('обучающая выборка:', Xtr.shape, ' отложенная:', Xte.shape)
print('значения пикселя:', Xtr.min(), '…', Xtr.max())
print('картинок каждого класса в обучении:', np.bincount(ytr))
print('параметров:', 64*32 + 32 + 32*10 + 10)

LOG = {1, 2, 3, 5, 10, 15, 20, 25, 30}
def log(ep, p):
    if ep in LOG:
        print(f'эпоха {ep:3d}   потеря {loss(p, Xtr, ytr):.4f}   '
              f'на обучении {acc(p, Xtr, ytr):.2f}%   на отложенной {acc(p, Xte, yte):.2f}%')

params = train(Xtr, ytr, on_epoch=log)
np.savez('params.npz', *params)
err = int(round((100 - acc(params, Xte, yte)) * len(yte) / 100))
print(f'\nточность на отложенной выборке: {acc(params, Xte, yte):.2f}% ({err} ошибок из {len(yte)})')
